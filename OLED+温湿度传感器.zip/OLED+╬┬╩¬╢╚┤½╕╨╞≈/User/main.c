#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "DHT11.h"
 
int main()
{
	OLED_Init();
		
	uint8_t buffer[5];
	float h,t;

	OLED_ShowChinese(20, 10, "温度");
	OLED_ShowChar(53, 10, ':', OLED_8X16);
	OLED_ShowChinese(20, 30, "湿度");
	OLED_ShowChar(53, 30, ':', OLED_8X16);

	OLED_Update();
	
	while(1)
	{
		uint8_t status = DHT_ReadData(buffer);
		if (status == 0)
		{
			h = buffer[0] + buffer[1] / 10.0;
			t = buffer[2] + buffer[3] / 10.0;
			
			OLED_ShowFloatNum(69, 10, t, 2, 1, OLED_8X16);
			OLED_ShowChinese(110, 10, "℃");
			
			OLED_ShowFloatNum(69, 30, h, 2, 1, OLED_8X16);
			OLED_ShowChar(110, 30, '%', OLED_8X16);
			
			OLED_Update();
		}
		else if(status == 1)
		{
			OLED_Clear();
			OLED_ShowString(60, 30, "CHECK ERR",OLED_8X16);
		}
		 else if (status == 2)
		{
			OLED_Clear();
			OLED_ShowString(60, 30, "NO RESP", OLED_8X16);
		}
		OLED_Update();
	}
}


 
